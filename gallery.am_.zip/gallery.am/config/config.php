<?php

define('    APP_ROOT', dirname(dirname(__FILE__)));
define('URL_ROOT', 'http://gallery.am/');
define('SITE_NAME', 'Gallery');
